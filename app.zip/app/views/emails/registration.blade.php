<h1>Welcome {{$fullName}}</h1>
<p>
  We are excited to have you on Trav.
</p>

<p>
Best Regards.
</p>
