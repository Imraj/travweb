@extends('master')

@section("content")
  <div class="col-xs-12 col-md-12 col-lg-12">
      <div class="col-xs-6 col-md-6 col-lg-6">
        <div class="services-wrapper">
          <div style="font-size:25px;"><b>T.G.M</b></div>
          <div><b>Transaction Id : ##############</b></div>
          <br/>
          <div><b>Ticket Id : ##############</b></div>
          <br/>
          <div><b>From </b> : Ogbomoso </div>
          <br/>
          <div><b>To</b> : Port-Harcourt</div>
          <br/>
          <div><b>Travel Date</b> : May 21,2016</div>
          <br/>
          <div><b>Ticket Purchase On</b> : May 19,2016</div>
        </div>
      </div>

      <div class="col-xs-6 col-md-6 col-lg-6">
        <div class="services-wrapper">
          <div style="font-size:25px;"><b>ABC Transport</b></div>
          <div><b>Transaction Id : ##############</b></div>
          <br/>
          <div><b>Ticket Id : ##############</b></div>
          <br/>
          <div><b>From </b> : Ogbomoso </div>
          <br/>
          <div><b>To</b> : Port-Harcourt</div>
          <br/>
          <div><b>Travel Date</b> : May 21,2016</div>
          <br/>
          <div><b>Ticket Purchase On</b> : May 19,2016</div>
        </div>
      </div>

      <div class="col-xs-6 col-md-6 col-lg-6">
        <div class="services-wrapper">
          <div style="font-size:25px;"><b>T.G.M</b></div>
          <div><b>Transaction Id : ##############</b></div>
          <br/>
          <div><b>Ticket Id : ##############</b></div>
          <br/>
          <div><b>From </b> : Ogbomoso </div>
          <br/>
          <div><b>To</b> : Port-Harcourt</div>
          <br/>
          <div><b>Travel Date</b> : May 21,2016</div>
          <br/>
          <div><b>Ticket Purchase On</b> : May 19,2016</div>
        </div>
      </div>

      

  </div>
@stop
