@extends('master')

@section('content')

  <div class="col-xs-12 col-sm-12 col-lg-12 col-md-12">
  
      <div class="col-xs-12 col-sm-8 col-lg-8 col-md-8">
          <h2>About Us</h2>
          <p>
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
            lorem ipsum lorem ipsum  lorem ipsum lorem ipsum
          </p>
    </div>

    <div class="col-xs-4 col-md-4 col-lg-4 col-sm-4">

    </div>
  </div>

@stop
