<?php

  class Activity extends Eloquent
  {
    
  }

 ?>
