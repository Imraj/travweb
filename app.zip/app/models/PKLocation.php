<?php

  class Pklocation extends Eloquent
  {
    public $fillable = ["agency_id","location_name","location_address"];
     public $timestamps = [];
  }
