<?php
  class Todo extends Eloquent
  {
    public $fillable = ["task","deadline"];
     public $timestamps = [];
  }

 ?>
