<?php
  class Place extends Eloquent
  {

  	   public $timestamps = [];
      public $fillable = ["name"];

  }

 ?>
